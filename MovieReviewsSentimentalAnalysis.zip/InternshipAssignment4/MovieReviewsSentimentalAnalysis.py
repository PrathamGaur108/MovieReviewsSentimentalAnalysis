# Movie Reviews Sentimental Analysis
from azure.ai.textanalytics import TextAnalyticsClient
from azure.core.credentials import AzureKeyCredential
import azure.cognitiveservices.speech as speechsdk
from azure.cognitiveservices.speech import AudioDataStream, SpeechConfig, SpeechSynthesizer, SpeechSynthesisOutputFormat
from azure.cognitiveservices.speech.audio import AudioOutputConfig

def authenticate_client():
    ta_credential = AzureKeyCredential('0fbe6bcae56e46f38e9750b025e8f036')
    text_analytics_client = TextAnalyticsClient(endpoint ='https://sohamsentiments.cognitiveservices.azure.com/', credential = ta_credential) 
    return text_analytics_client

def sentiment_analysis_example(client):
    documents = []
    documents.append(cont)
    response = client.analyze_sentiment(documents = documents)[0]

    positive = response.confidence_scores.positive
    neutral = response.confidence_scores.neutral
    negative = response.confidence_scores.negative
    sentiment = None
    if(positive > neutral):
        if(positive > negative):
            sentiment = "Positive"
        else:
            sentiment = "Negative"
    else:
        if(neutral > negative):
            sentiment = "Neutral"
        else:
            sentiment = "Negative"
    
    print("General Document Sentiment: {}".format(sentiment))
    dic={"sentiment":sentiment,"positive":positive*100,"neutral":neutral*100,"negative":negative*100}

    try:
        speech_config = SpeechConfig(subscription="25eb8d0da8934f59a33b6e174dd44beb", region="eastus")
        speech_config.speech_synthesis_voice_name="en-IN-NeerjaNeural"
        speech_synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config)
        print("Sentiment Analysis of reviews of Mortal Kombat...")
        print(dic)
        text = "Sentiment Analysis of reviews of Mortal Kombat..." + str(dic)

        result = speech_synthesizer.speak_text_async(text).get()
    except:
        print('error')

client = authenticate_client()
print("Reading file...")
file = open("MortalKombatReviews.txt","r")
cont = file.read()
sentiment_analysis_example(client)
